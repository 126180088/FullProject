﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    /// <summary>
    /// 实体类:用户信息
    /// 
    /// </summary>
    
    [ActiveRecord]
    public class SysUser : BaseEntity
    {
        /// <summary>
        /// 用户名
        /// </summary>
        [Property(NotNull = true, Length = 20)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过20个字符")]
        [Display(Name = "用户名")]
        public virtual string Account { get; set; }

        /// <summary>
        /// 帐户名
        /// </summary>
        [Property(NotNull = true, Length = 50)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过50个字符")]
        [Display(Name = "帐号")]
        //[Remote("AjaxCheckAccount", "User", ErrorMessage = "该帐号已存在")]//远程验证登录是否存在，AdditionalFields表示除了当前要获取Account属性值外，还需要从视图中获取的其他属性值
        public virtual string AccountName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [Property(NotNull = true, Length = 50)]
        [Display(Name = "密码")]
        public virtual string Password { get; set; }

        /// <summary>
        /// 是否激活，默认应该为true
        /// </summary>
        [Property(NotNull = true)]
        [Required]
        [Display(Name = "激活")]
        public virtual bool IsActive { get; set; }

        /// <summary>
        /// 0:普通用户 1:超级管理员
        /// </summary>
        [Property(NotNull = true)]
        [Display(Name = "权限")]
        public int Power { get; set; }

        /// <summary>
        /// 编号
        /// </summary>
        [Property(NotNull = true, Length = 12)]
        [Display(Name = "编号")]
        public virtual string TelNo { get; set; }


        [HasMany(typeof(Vote),
            Table = "Vote",
            ColumnKey = "UserId",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Vote> Votes { get; set; }
    }
}
