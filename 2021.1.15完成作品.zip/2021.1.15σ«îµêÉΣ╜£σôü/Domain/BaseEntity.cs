﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Domain
{
    /// <summary>
    /// Data : 2021/1/10
    /// </summary>
    /// <typeparam name="T"></typeparam>
    //public class BaseEntity<T> : ActiveRecordBase
    //    where T : class
    //{
    //    /// <summary>
    //    /// ID
    //    /// </summary>
    //    [PrimaryKey(PrimaryKeyType.Native)]
    //    public virtual int ID { get; set; }
    //}
    public class BaseEntity
    {
        [PrimaryKey(PrimaryKeyType.Identity)]//主键的类型为自增型
        [Display(AutoGenerateField = false)]//在生成视图时不生成本属性
        public virtual int ID { get; set; }//主键

        //[Property("Version")]//数据库中与Version属性对应的字段
        //[Display(AutoGenerateField = false)]//在生成视图时不生成本属性
        //public virtual int Version { get; set; }//数据版本，实现同步数据处理
    }
}
