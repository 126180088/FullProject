﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ActiveRecord]
    public  class Singer : BaseEntity
    {
        [Property]
        [Display(Name = "选手名称")]
        [Required(ErrorMessage = "请输入选手名称")]
        [StringLength(20, ErrorMessage = "最大支持20个字符")]
        public string SingerName { get; set; }

        [Property]
        [Display(Name = "图片路径")]
        public string Image { get; set; }

        [Property]
        [Display(Name = "性别")]
        public int Gender { get; set; }

        [Property]
        [Display(Name = "联系编号")]
        public string Number { get; set; }

        [Property]
        [Display(Name = "状态")]
        public int Status { get; set; }//描述

        [HasAndBelongsToMany(typeof(Match),
            Table = "MatchSinger",
            ColumnKey = "SingerId",
            ColumnRef = "MatchId",
            Cascade = ManyRelationCascadeEnum.None,
            Inverse = false,
            Lazy = false)]
        public virtual IList<Match> Matchs { get; set; }

        [HasMany(typeof(Vote),
            Table = "Vote",
            ColumnKey = "UserID",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Vote> UserVotes { get; set; }

        [HasMany(typeof(Vote),
            Table = "Vote",
            ColumnKey = "SingerID",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Vote> SingerVotes { get; set; }

        [HasMany(typeof(Result),
            Table = "Result",
            ColumnKey = "SingerID",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Result> ResultVotes { get; set; }

    }
}
