﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    /// <summary>
    /// 客户：托运人和收货人
    /// </summary>
    [ActiveRecord("Client")]
    public class Client : BaseEntity
    {
        [Property(NotNull = true, Length = 20)]
        [Required(ErrorMessage = "名称必填!")]
        [StringLength(8, MinimumLength = 0,
            ErrorMessage = "所填字符不得超过20个")]
        [Display(Name = "比赛名字")]
        public string MatchName { get; set; }

        [Property(NotNull = true, Length = 50)]
        [Required(ErrorMessage = "名称必填!")]
        [StringLength(8, MinimumLength = 0,
            ErrorMessage = "所填字符不得超过50个")]
        [Display(Name = "比赛说明")]
        public string Description { get; set; }

        [Property(NotNull = true, Length = 20)]
        [Required(ErrorMessage = "地址必填!")]
        [StringLength(20, MinimumLength = 0,
            ErrorMessage = "字符不得超过20个")]
        [Display(Name = "比赛地址")]
        public string Location { get; set; }

        [Property]
        [Display(Name = "比赛开始时间")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime StartTime { get; set; }

        [Property]
        [Display(Name = "比赛结束时间")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EndTime { get; set; }

        [Property]
        [Display(Name = "状态")]
        public virtual MatchStatus Status { get; set; }
    }
}
