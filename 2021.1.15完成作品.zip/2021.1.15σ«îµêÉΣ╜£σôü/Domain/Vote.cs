﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ActiveRecord]
    public class Vote : BaseEntity
    {
        /// <summary>
        /// 状态
        /// </summary>
        [Property(NotNull = true)]
        [Display(Name = "状态")]
        public int Status { get; set; }

        [BelongsTo(Type = typeof(SysUser),
            Column = "UserId",
            Lazy = FetchWhen.OnInvoke,
            Insert = true, Update = false)]
        public SysUser UserVotes { get; set; }

        [BelongsTo(Type = typeof(Match),
            Column = "MatchId",
            Lazy = FetchWhen.OnInvoke,
            Insert = true, Update = false)]
        public Match MatchVotes { get; set; }

        [BelongsTo(Type = typeof(Singer),
            Column = "SingerId",
            Lazy = FetchWhen.OnInvoke,
            Insert = true, Update = false)]
        public Singer SingerVotes { get; set; }
    }
}
