﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ActiveRecord]
    public class Result : BaseEntity
    {
        /// <summary>
        /// 投票结果描述
        /// </summary>
        [Property]
        [Display(Name = "投票结果描述")]
        public string Description { get; set; }

        /// <summary>
        /// 投票结果票数
        /// </summary>
        [Property]
        [Display(Name = "投票结果票数")]
        public int Temp { get; set; }

        /// <summary>
        /// 投票结果状态
        /// 0：正常    1：禁用
        /// </summary>
        [Property]
        [Display(Name = "投票结果状态")]
        public int Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [BelongsTo(Type = typeof(Match),
            Column = "MatchId",
            Lazy = FetchWhen.OnInvoke,
            Insert = true, Update = false)]
        public Match ResultVotes { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [BelongsTo(Type = typeof(Singer),
            Column = "SingerId",
            Lazy = FetchWhen.OnInvoke,
            Insert = true, Update = false)]
        public Singer SingerVotes { get; set; }
    }
}
