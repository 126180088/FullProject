﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    /// <summary>
    /// 比赛状态
    /// </summary>
    public enum MatchStatus
    {
        /// <summary>
        /// 未开始
        /// </summary>
        WaitingForDispatch = 1,
        /// <summary>
        /// 进行中
        /// </summary>
        Delivering,
        /// <summary>
        /// 结束
        /// </summary>
        Done
    }
}
