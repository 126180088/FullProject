﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    [ActiveRecord("Match")]
    public  class Match : BaseEntity
    {
        [Property]
        [Display(Name = "比赛名字")]
        public string MatchName { get; set; }

        [Property]
        [Display(Name = "比赛说明")]
        public string Description { get; set; }

        [Property]
        [Display(Name = "比赛地址")]
        public string Location { get; set; }

        [Property]
        [Display(Name = "比赛开始时间")]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime StartTime { get; set; }

        [Property]
        [Display(Name = "比赛结束时间")]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EndTime { get; set; }

        [Property]
        [Display(Name = "状态")]
        public virtual MatchStatus Status { get; set; }


        [HasAndBelongsToMany(typeof(Singer),
            Table = "MatchSinger",
            ColumnKey = "MatchId",
            ColumnRef = "SingerId",
            Cascade = ManyRelationCascadeEnum.None,
            Inverse = false,
            Lazy = false)]
        public virtual IList<Singer> Singers { get; set; }

        [HasMany(typeof(Vote),
            Table = "Vote",
            ColumnKey = "MatchId",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Vote> Votes { get; set; }

        [HasMany(typeof(Result),
            Table = "Result",
            ColumnKey = "MatchId",
            Lazy = false,
            Inverse = true)]
        public virtual IList<Result> MatchVotes { get; set; }

    }


}
