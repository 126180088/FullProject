﻿using Castle.ActiveRecord;
using Castle.ActiveRecord.Queries;
using Domain;
using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Manager
{
    public  class MatchManager : BaseManager<Match>
    {
        #region hql测试 create by lengyahong

        //public Match GetMatchTest(string startStation, string provinceName, int creatorID)
        //{
        //    Match order = null;

        //    //定义hql语句
        //    StringBuilder hql = new StringBuilder();

        //    #region hql定义
        //    //最简单的写法
        //    hql.Append("from TransportOrder tOrder");
        //    hql.Append(" where tOrder.StartStation = :StartStation ");
        //    hql.Append(" and tOrder.ProvinceOfDestionation.Name = :ProvinceName");//注意此句，设置关联属性的属性为条件，只能使用[Blongsto]属性
        //    hql.Append(" and tOrder.Creator.ID = :CreatorID");//注意此句，设置关联属性的属性为条件，只能使用[Blongsto]属性

        //    #endregion

        //    #region 查询
        //    //第一种方法，很灵活
        //    //获取管理User的session对象
        //    using (ISession session = ActiveRecordBase.holder.CreateSession(typeof(Match)))
        //    {
        //        //创建执行对象
        //        IQuery query = session.CreateQuery(hql.ToString());

        //        //给参数赋值
        //        query.SetParameter("StartStation", startStation);
        //        query.SetParameter("ProvinceName", provinceName);
        //        query.SetInt32("CreatorID", creatorID);

        //        //执行查询，并返回满足条件的第一条数据，如果对象不存在，则返回null
        //        order = query.List<Match>().FirstOrDefault();
        //    }

        //    /*
        //    //第2中方法，使用简单，相对死板
        //    //使用SimpleQuery查询，该查询的结果为数组，即多行数据
        //    SimpleQuery query = new SimpleQuery(typeof(TransportOrder), hql.ToString());

        //    //给参数赋值
        //    query.SetParameter("StartStation", startStation);
        //    query.SetParameter("ProvinceName", provinceName);
        //    query.SetParameter("CreatorID", creatorID);

        //    //执行并返回查询结果
        //    TransportOrder[] list = (TransportOrder[])ActiveRecordBase.ExecuteQuery(query);//注意这句话的使用
        //    if (list != null && list.Length > 0)
        //        order = list[0];
        //    */
        //    #endregion

        //    return order;
        //}

        //public IList<Match> GetMatchTest(string matchName, string location, string description,string startTime,String endTime)
        //{
        //    //定义hql语句
        //    StringBuilder hql = new StringBuilder();
        //    StringBuilder where = new StringBuilder();
        //    hql.Append("from Match tOrder");

        //    //多条件组合查询的方法，设置查询条件
        //    if (!string.IsNullOrEmpty(matchName))
        //    {
        //        where.Append(" where tOrder.MatchName = :matchName ");
        //    }
        //    if (!string.IsNullOrEmpty(location))
        //    {
        //        where.Append("tOrder.Location = :location");
        //    }
        //    if (!string.IsNullOrEmpty(description))
        //    {
        //        where.Append("tOrder.Description = :description");
        //    }
        //    if (!string.IsNullOrEmpty(startTime))
        //    {
        //        where.Append("tOrder.StartTime = :startTime");
        //    }
        //    if (!string.IsNullOrEmpty(endTime))
        //    {
        //        where.Append("tOrder.EndTime = :endTime");
        //    }
        //    //增加查询条件
        //    hql.Append(where);


        //    SimpleQuery query = new SimpleQuery(typeof(Match), hql.ToString());

        //    //给参数赋值
        //    if (!string.IsNullOrEmpty(matchName))
        //    {
        //        query.SetParameter("MatchName", matchName);
        //    }
        //    if (!string.IsNullOrEmpty(location))
        //    {
        //        query.SetParameter("Location", location);
        //    }
        //    if (!string.IsNullOrEmpty(description))
        //    {
        //        query.SetParameter("Description", description);
        //    }
        //    if (!string.IsNullOrEmpty(startTime))
        //    {
        //        query.SetParameter("StartTime", startTime);
        //    }
        //    if (!string.IsNullOrEmpty(endTime))
        //    {
        //        query.SetParameter("EndTime", endTime);
        //    }
        //    //执行并返回查询结果
        //    IList<Match> list = ActiveRecordBase.ExecuteQuery(query) as IList<Match>;
        //    return list;
        //}
        #endregion
    }
}
