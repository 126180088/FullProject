﻿using Core;
using Domain;
using Manager;
using NHibernate.Criterion;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web.Apps;

namespace Web.Controllers
{
    public class MatchController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult MatchMa()
        {
            IList<Match> list = Container.Instance.Resolve<IMatchService>()
                                    .GetAll();
            return View(list);
        }
        [HttpPost]
        public ActionResult MatchMa(int i)
        {
            return View();
        }

        [HttpGet]
        public ActionResult MatchAdd()
        {
            return View();

        }

        [HttpPost]
        public ActionResult MatchAdd(string MatchName, string Location, string Description, DateTime StartTime, DateTime EndTime)
        {
            try
            {
                Match match = new Match();
                match.MatchName = MatchName;
                match.Location = Location;
                match.Description = Description;
                match.StartTime = StartTime;
                match.EndTime = EndTime;
                match.Status = MatchStatus.WaitingForDispatch;

                Container.Instance.Resolve<IMatchService>()
                    .Create(match);

            }
            catch (Exception e)
            {
                return Content(e.Message);
            }
            return Content("success");

        }
        [HttpGet]
        public ActionResult MAddS(int id)
        {
            Match match = Container.Instance.Resolve<IMatchService>().Get(id);

            IList<Singer> list = Container.Instance.Resolve<ISingerService>()
                                   .GetAll();
            ViewBag.singerList = list;
            return View(match);
        }
        [HttpPost]
        public ActionResult MAddS(int id,int[] SingerList)
        {
            try
            {
                Result result = new Result();

                //查询到该id的Match
                Match match = Container.Instance.Resolve<IMatchService>().Get(id);

                //清空比赛对应关联的歌手列表
                match.Singers.Clear();

                if (SingerList != null)
                {
                    for (int i = 0; i < SingerList.Length; i++)
                    {
                        //遍历选手ID数组，添加到比赛的选手集合
                        match.Singers.Add(Container.Instance.Resolve<ISingerService>().Get(SingerList[i]));
                    }
                }

                //提交更新
                Container.Instance.Resolve<IMatchService>()
                    .Update(match);


                //delete* from user_course where userid = 1 and courseid = 2

                //此处添加项目对应歌手的投票结果表，以便后期使用
                if (match.Singers.Count() != 0)
                {
                    foreach (var item in match.Singers)
                    {
                        //查询对应Id是否为空，如果是空的时候才生成的
                        IList<QueryConditions> queryConditions = new List<QueryConditions>();
                        QueryConditions query1 = new QueryConditions();
                        query1.Operator = "=";
                        query1.PropertyName = "ResultVotes.ID";
                        query1.Value = match.ID;
                        queryConditions.Add(query1);
                        QueryConditions query2 = new QueryConditions();
                        query2.Operator = "=";
                        query2.PropertyName = "SingerVotes.ID";
                        query2.Value = item.ID;
                        queryConditions.Add(query2);
                        //建立查询条件（结束），开始查询
                        IList<Result> resultList = Container.Instance.Resolve<IResultService>().GetAll(queryConditions);
                        if (resultList.Count == 0)
                        {
                            result.Status = 0;
                            result.Description = "暂无";
                            result.Temp = 0;
                            result.SingerVotes = item;
                            result.ResultVotes = match;
                            Container.Instance.Resolve<IResultService>().Create(result);
                        }
                    }
                }
            }
            catch (Exception e)
            {

                return Content(e.Message);
            }
            return Content("success");
        }
        [HttpPost]
        public ActionResult DeleteMatch(int id)
        {
            Container.Instance.Resolve<IMatchService>()
                .Delete(id);
            return Content("success");
        }

    }
}