﻿using Core;
using Domain;
using Manager;
using NHibernate.Criterion;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web.Controllers
{
    public class VoteController : Controller
    {
        /// <summary>
        /// 选择比赛投票
        /// </summary>
        [HttpGet]
        public ActionResult Index()
        {
            IList<Match> list = Container.Instance.Resolve<IMatchService>()
                                    .GetAll();
            return View(list);
        }
        [HttpPost]
        public ActionResult Index(int i)
        {
            return View();
        }
        /// <summary>
        /// 开始进行投票
        /// </summary>
        public ActionResult Voting(int id)
        {
            //查找比赛
            Match match = Container.Instance.Resolve<IMatchService>().Get(id);
            TempData["Match"] = match;
            return View(match);
        }
        [HttpPost]
        public ActionResult Votings(int id)
        {
            SysUser user = Session["LoginUser"] as SysUser;     //在其它地方使用LoginUser的用法
            Match match = TempData["Match"] as Match;
            Vote vote = new Vote();
            Singer singer = Container.Instance.Resolve<ISingerService>().Get(id);
            vote.Status = 0;
            vote.MatchVotes = match;
            vote.SingerVotes = singer;
            vote.UserVotes = user;
            Container.Instance.Resolve<IVoteService>().Create(vote);



            //添加投票后，立马更新投票的结果表

            //建立查询条件（开始）
            IList<QueryConditions> queryConditions = new List<QueryConditions>();
            QueryConditions query1 = new QueryConditions();
            query1.Operator = "=";
            query1.PropertyName = "ResultVotes.ID";
            query1.Value = match.ID;
            queryConditions.Add(query1);
            QueryConditions query2 = new QueryConditions();
            query2.Operator = "=";
            query2.PropertyName = "SingerVotes.ID";
            query2.Value = singer.ID;
            queryConditions.Add(query2);
            //建立查询条件（结束），开始查询
            IList<Result> result = Container.Instance.Resolve<IResultService>().GetAll(queryConditions);
            result[0].Temp = result[0].Temp + 1;
            Container.Instance.Resolve<IResultService>()
                    .Update(result[0]);

            return Content("success");
        }
        [HttpGet]
        public ActionResult Voted()
        {
            IList<Match> list = Container.Instance.Resolve<IMatchService>()
                                   .GetAll();
            return View(list);
        }
        [HttpPost]
        public ActionResult Voted(int i)
        {
            return View();
        }
        public ActionResult UserVote(int id)
        {
            string MatchId = id.ToString();
            //查找对于比赛的投票(精确查询）
            IList<QueryConditions> queryConditions = new List<QueryConditions>();
            QueryConditions query = new QueryConditions();
            query.Operator = "=";
            query.PropertyName = "MatchVotes.ID";
            query.Value = MatchId;
            //向条件集合添加查询条件，每个条件之间默认为And关系
            queryConditions.Add(query);
            IList<Vote> votes = Container.Instance.Resolve<IVoteService>().GetAll(queryConditions);

            return View(votes);
        }


        /// <summary>
        /// 开始进行投票
        /// </summary>
        /// 
        public ActionResult Result(int id)
        {
            IList<QueryConditions> queryConditions = new List<QueryConditions>();
            QueryConditions query = new QueryConditions();
            query.Operator = "=";
            query.PropertyName = "ResultVotes.ID";
            query.Value = id;
            queryConditions.Add(query);
            IList<Result> result = Container.Instance.Resolve<IResultService>().GetAll(queryConditions);

            return View(result);
        }
    }
}