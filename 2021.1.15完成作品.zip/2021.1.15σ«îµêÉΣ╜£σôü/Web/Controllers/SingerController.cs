﻿using Core;
using Domain;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web.Controllers
{
    public class SingerController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult SingerMa()
        {
            IList<Singer> list = Container.Instance.Resolve<ISingerService>()
                                    .GetAll();
            return View(list);
        }
        [HttpPost]
        public ActionResult SingerMa(int i)
        {
            return View();
        }
        [HttpGet]
        public ActionResult SingerAdd()
        {
            return View();

        }

        [HttpPost]
        public ActionResult SingerAdd(string SingerName, string Gender,string Number)
        {
            try
            {
                Singer singer = new Singer();
                singer.SingerName = SingerName;
                if (Gender == "男")
                {
                    singer.Gender = 0;
                }
                else
                {
                    singer.Gender = 1;
                }
                singer.Number = Number;
                singer.Status = 0;
                Container.Instance.Resolve<ISingerService>().Create(singer);
            }
            catch (Exception e)
            {
                return Content(e.Message);
    }
            return Content("success");
        }

        [HttpPost]
        public ActionResult DeleteSinger(int id)
        {
            Container.Instance.Resolve<ISingerService>()
                .Delete(id);
            return Content("success");
        }
    }
}