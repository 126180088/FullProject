﻿
using Core;
using Domain;
using NHibernate.Criterion;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web.Apps;


namespace Web.Controllers
{
    public class SysUserController : BaseController
    {
        #region 登录
        [HttpGet]
        public ViewResult Login()
        {
            Domain.SysUser model = new SysUser();
            model.AccountName = "admin";

            return View(model);
        }

        [HttpPost]
        //public ActionResult Login(string account,string password)
        public ActionResult Login(SysUser model)
        {
            model.Password = AppHelper.EncodeMd5(model.Password);//用MD5加密

            //访问数据库，根据用户名和密码获取用户信息
            ISysUserService userService = Container.Instance.Resolve<ISysUserService>();
            Domain.SysUser loginedUser = userService.Login(model.Account, model.Password);
            if (loginedUser != null)//当用户名和密码正确时
            {
                Session["LoginUser"] = loginedUser;
                //保存用户登录信息
                AppHelper.LoginedUser = loginedUser;
                //获取当前登录对象的角色信息，待用
                //IList<Role> roleList = loginedUser.Roles;
                if (loginedUser.Power==0)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return RedirectToAction("Index", "Vote");
                }

                //页面跳转到主页面
               
            }
            else
            {
                //如果登录不成功，则向用户提示错误信息
                ViewBag.ErrorMsg = "用户名或密码错误。";
                return View(model);
            }
        }
        #endregion

        /// <summary>
        /// 分页展示user信息,默认为第一页
        /// </summary>
        /// <param name="pageIndex">页码</param>
        /// <param name="AccountName">查询条件，用户名</param>
        public ActionResult Index(int pageIndex = 1, string AccountName = "")
        {
            //1获取查询条件
            //2组织查询条件(必须的修改)
            IList<ICriterion> queryConditions = new List<ICriterion>();
            if (!string.IsNullOrEmpty(AccountName))
            {
                //模糊匹配
                //queryConditions.Add(Expression.Like("Account",AccountName));
                queryConditions.Add(new LikeExpression("Account", AccountName));
            }

            int count = 0;//用于存放满足条件的记录总
            //3设置排序表达式集合(必须的修改)
            IList<Order> listOrder = new List<Order>() {
                new Order("ID", true)

            };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

            //4通过容器调用分页方法(修改查询的数据类型)
            IList<SysUser> list = Container.Instance.Resolve<ISysUserService>()
                .GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //5将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<SysUser> pageList =
                list.ToPageList<SysUser>(pageIndex, PagerHelper.PageSize, count);

            //6返回到视图或则跳转到其他的Action
            return View(pageList);//用pageList集合填充页面。
        }


        private IList<ICriterion> GetCondition(string AccountName = "")//生成查询条件,AccountName变量默认为空
        {
            IList<ICriterion> queryConditions = new List<ICriterion>();//实例化一个查询条件集合
            if (!string.IsNullOrEmpty(AccountName))//如果AccountName变量不为空
            {
                //queryConditions.Add(Expression.Like("AccountName",AccountName));
                queryConditions.Add(new LikeExpression("AccountName", AccountName));//在查询条件集合中加入一个模糊查询条件
            }
            return queryConditions;//返回查询条件集合
        }

        [HttpGet]
        public ActionResult Create()//这个方法用于mvc展示页面
        {
            Domain.SysUser user = new Domain.SysUser();//实体化一个空的实体

            ////准备视图需要的角色信息
            //SetRoles();

            return View(user);//用一个视图展示user
        }

        ///// <summary>
        ///// 提交创建用户
        ///// 说明：获取表单值的方法：
        ///// 1：获取Model对象，将Model对象作为参数，可获取对象中的所有值
        ///// 2：获取指定控件的值，将控件名称（控件的name属性）作为参数，可获取该控件的值
        ///// </summary>
        ///// <param name="user">提交的用户对象</param>
        ///// <param name="hdSelectedIds">提交的角色ID串，每个角色ID中间用“,”隔开</param>
        ///// <returns></returns>
        //[HttpPost]
        //public ActionResult Create(Domain.SysUser user, string hdSelectedIds)//这个方法用于mvc创建user
        //{
        //    user.Password = Container.Instance.Resolve<ISystemSettingService>().GetDefaultPassword();//获取系统默认的用户密码
        //    if (ModelState.IsValid)//如果user实体的数据合法
        //    {
        //        //判断是否存在
        //        if (Container.Instance.Resolve<SysUserService>().AccountCheck(0, user.Account))
        //        {
        //            ModelState.AddModelError("Account", "帐号已存在");//返回提示信息
        //            SetRoles();//提供角色供视图显示
        //            return View(user);//停留在原页面,返回User对象，目的是保留提交前输入的用户信息
        //        }

        //        Container.Instance.Resolve<SysUserService>().Create(user, hdSelectedIds.Replace(",,", ","));//创建user实体
        //        return RedirectToAction("Index");//跳转到Index页面
        //    }

        //    SetRoles();//提供角色供视图显示
        //    return View(user);//停留在原页面,返回User对象，目的是保留提交前输入的用户信息
        //}

        public ActionResult Edit(int id)//当调用edit页面时将传入一个id,这个id代表要修改的哪一行数据
        {
            SysUser user = Container.Instance.Resolve<ISysUserService>().Get(id);//根据id获取user实体
            return View(user);//将这个user实体显示在edit页面上对应的控件
        }

        /// <summary>
        /// 编辑用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Edit(SysUser model)//当用户点击“保存”按钮时要执行的方法
        {
            if (ModelState.IsValid)//如果实体的数据合法
            {
                //从数据库中通过ID获取完整的用户信息（修改之前的数据）
                SysUser newUser = Container.Instance.Resolve<ISysUserService>().Get(model.ID);
                //用视图中新修改的值替换掉查询回来的值
                newUser.AccountName = model.AccountName;
                newUser.Account = model.Account;

                Container.Instance.Resolve<ISysUserService>().Update(newUser);//更新实体
                return RedirectToAction("Index");//跳转到列表页面
            }
            return View(model);//停留在原页面
        }

        /// <summary>
        /// 查看明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ViewResult Details(int id)//当调用edit页面时将传入一个id,这个id代表要显示的哪一行数据
        {
            Domain.SysUser user = Container.Instance.Resolve<ISysUserService>().
                Get(id);//根据id获取user实体
            return View(user);//将这个user实体显示在details页面上对应的控件
        }

        /// <summary>
        /// 状态变更
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <returns></returns>
        public ActionResult SwitchIsActive(int id)
        {
            Container.Instance.Resolve<ISysUserService>().SwitchIsActive(id);//调用业务逻辑层方法，切换用户状态
            return RedirectToAction("Index");//跳转到列表页面
        }


        /// <summary>
        /// 配置用户对应的橘色
        /// </summary>
        /// <param name = "id" > 用户ID </ param >
        /// < returns ></ returns >
        //[HttpGet]
        //public ViewResult AssignRole(int id)
        //{
        //    SysUser user = Container.Instance.Resolve<SysUserService>().Get(id);

        //    获取所有的并且是启用状态的角色
        //    说明：执行本操作前，请先在domain层定义扩展属性IsChecked，用于视图状态的显示
        //    IList<Role> roleList = Container.Instance.Resolve<IRoleService>().GetAll()
        //        .Where(m => m.IsActive == true)
        //        .ToList();

        //    判断列表中的角色是否是用户对应的角色，如果是则，则设置当前角色为选中状态
        //    if (user.Roles != null)
        //    {
        //        foreach (var item in roleList)
        //        {
        //            if (user.Roles.Where(m => m.ID == item.ID).Count() > 0)
        //                item.IsChecked = true;
        //        }
        //    }

        //    通过向视图传递所有的角色信息
        //    ViewBag.RoleList = roleList;

        //    return View(user);
        //}

        ///// <summary>
        ///// 配置角色
        ///// </summary>
        ///// <param name="id">用户ID，此处的id为post提交的action中的 user/AssignRole/id值，此参数可以与userid中选择一个即可</param>
        ///// <param name="userId">用户ID，（推荐使用本参数，目的是教学中方便学生理解）</param>
        ///// <param name="hdSelectedIds">用,分开的角色ID</param>
        ///// <returns></returns>
        //[HttpPost]
        ////public ActionResult AssignRole(int id, string hdSelectedIds)
        //public ActionResult AssignRole(int userId, string hdSelectedIds)
        //{
        //    Container.Instance.Resolve<IUserService>().AssignRole(userId, hdSelectedIds.Replace(",,", ","));
        //    return RedirectToAction("Index");//跳转到列表页面
        //}

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <returns></returns>
        public ActionResult ChangePassword()
        {
            return View();
        }

        public ViewResult UnAuthorized()
        {
            return View();
        }

        //#region 扩展方法
        ///// <summary>
        ///// 将添加用户信息需要的角色信息传递到视图中
        ///// </summary>
        //private void SetRoles()
        //{
        //    //取出系统中的所有角色
        //    IList<Role> roleList = Container.Instance.Resolve<IRoleService>().GetAll()
        //        .Where(m => m.IsActive == true) //使用lamdba表达式过滤未启用状态的角色
        //        .ToList();  //在使用了lamdba表达式之后要使用ToList()转换成原始对象
        //    //通过ViewBag传递到视图中去
        //    ViewBag.RoleList = roleList;
        //}
        //#endregion

        /// <summary>
        /// 删除用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Delete(int id)
        {
            Container.Instance.Resolve<ISysUserService>().Delete(id);
            return RedirectToAction("Index");//跳转到列表视图
        }
    }
}
