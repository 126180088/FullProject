﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web.Apps;

namespace Web.Controllers
{
    public class BaseController : Controller
    {
        // GET: Base
        //重写OnActionExecuting方法，这个方法在Action执行时执行
        //protected override void OnActionExecuting(ActionExecutingContext filterContext)
        //{
        //    GetCurrentUserPrivilege();
        //    base.OnActionExecuting(filterContext);
        //    return;

        //    #region 权限验证
        //    string controllerName = filterContext.Controller.ToString();//获取控制器名称
        //    string actionName = filterContext.ActionDescriptor.ActionName;//获取Action的名称
        //    //如果是用户请求登录页面则不验证权限
        //    if ((controllerName.Equals("ZDSoft.LMS.Web.Controllers.UserController") && (actionName == "Login" || actionName == "UnAuthorized"))
        //        || (controllerName.Equals("ZDSoft.LMS.Web.Controllers.HomeController") && (actionName == "Index")))
        //    {
        //        base.OnActionExecuting(filterContext);//执行mvc默认的行为
        //    }
        //    else
        //    {
        //        if (AppHelper.LoginedUser == null)//如果登录信息丢失
        //        {
        //            Redirect(filterContext);//跳转到登录页面
        //            Response.End();//结束响应
        //        }
        //        else
        //        {
        //            if (!IsAuthenticated(controllerName, actionName))//判断登录用户是否有权限访问当前页面，如果没有访问权限
        //            {
        //                //强行跳转到“未授权页面”
        //                //filterContext.HttpContext.Response.Redirect("~/User/UnAuthorized?ReturnUrl=" + Server.UrlEncode(Request.Url.OriginalString), false);
        //            }
        //            else
        //            {
        //                GetCurrentUserPrivilege();//设置动态属性，用于在母版页上显示菜单
        //                base.OnActionExecuting(filterContext);
        //            }
        //        }
        //    }
        //    #endregion

        //}

        ///// <summary>
        ///// 获取当前用户功能模块
        ///// </summary>
        //private void GetCurrentUserPrivilege()
        //{
        //    ViewBag.PrivilegeList = AppHelper.Privileges;
        //}

        ///// <summary>
        ///// 根据转入的控制器名称和Action名称判断当前登录用户是否有访问权限
        ///// </summary>
        ///// <param name="controllerClassName">控制器名称</param>
        ///// <param name="actionName">Action名</param>
        ///// <returns>true:有访问权限，false:没有访问权限</returns>
        //private bool IsAuthenticated(string controllerClassName, string actionName)
        //{
        //    var privList = AppHelper.Privileges;
        //    if (privList == null)//如果登录用户的权限列表为空则没有访问权限
        //    {
        //        return false;
        //    }
        //    if (privList.Where(o => o.ControllerName == controllerClassName).Count() > 0)
        //    {
        //        return true;
        //    }
        //    return false;
        //}

        //页面跳转
        private void Redirect(ActionExecutingContext filterContext)
        {
            filterContext.HttpContext.Response.Redirect("~/User/Login?ReturnUrl=" + Server.UrlEncode(Request.Url.OriginalString), true);
        }
    }
}