﻿using Domain;
using Manager;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Component
{
    public class MatchComponent : BaseComponent<Match, MatchManager>, IMatchService
    {
        /// <summary>
        /// 更新订单信息
        /// </summary>
        /// <param name="entity"></param>
    }
}
